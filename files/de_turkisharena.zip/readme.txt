=============================================================================================
Author:
cruelstroke (email@deryabal.com)
=============================================================================================
Map Instructions:
Copy all files into your ..\Steam\steamapps\common\Half-Life\cstrike directory,
launch game and enjoy!
=============================================================================================