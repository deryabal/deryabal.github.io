=============================================================================================
Author:
Derya "cruelstroke" Bal (email@deryabal.com) and Doğaç Yavuz
=============================================================================================
Map Instructions:
Copy football.pk3 into your ..\Quake 3 Arena\baseq3 directory,
launch game and enjoy!
=============================================================================================