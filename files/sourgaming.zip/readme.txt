=============================================================================================

Title: sourgaming
Filenames: sourgaming.pk3, readme.txt
File size: 6.9mb, it's a big mac!
Author: cruelstroke
Address: deryabal@gmail.com

Description: sourgaming'e ithafen;
bu harita #sourgaming kanali icin yapilmis bir hobi urunudur.
desteklerinden oturu gelaek/skos, aib ve fuayfsilfm/vesc'ye sonsuz tesekkurler.
bu guzel oyunu oynamamizi saglayan disq ve id calisanlarina da kocaman opucukler.

=============================================================================================

Map Instructions:

unzip sourgaming.pk3 into your ..\quake iii arena\baseq3 directory.
launch game and go into the skirmish option and scan for levelshot.
enjoy ulan!

=============================================================================================

Information:

Test Machine: intel c2d e6750, ocz 2gb ddr2 800mhz platinum 2, msi 8800gt 512mb oc edition

In game Support: yes
SP BOT support: yes
Deathmatch: yes
Team Deathmatch: yes
New Textures: yes

=============================================================================================

Construction:

Editor Used: gtkradiant 1.5, q3build, photoshop cs3
Known Bugs: nothing
Total Compile Time: half hour

=============================================================================================

Copyright:

no copyright..

=============================================================================================