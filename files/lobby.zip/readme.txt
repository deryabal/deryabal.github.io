=============================================================================================

Title: Lobby [The Matrix]
Filenames: lobby.pk3, readme.txt
File size: 6.4mb
Author: cruelstroke
Address: deryabal@gmail.com

Description: shoot and fun!

map list;

lobby - Lobby Shootout (double size for dm, tdm)
lobby2 - Lobby Rocket (double size for dm, tdm)
lobby3 - Lobby Instagib (double size for dm, tdm)

lobby4 - Lobby Shootout Duel (default size for dm, tourney)
lobby5 - Lobby Rocket Duel (default size for dm, tourney)
lobby6 - Lobby Instagib Duel (default size for dm, tourney)

=============================================================================================

Map Instructions:

copy lobby.pk3 into your ..\quake iii arena\baseq3 directory.
launch game and go into the skirmish option and scan for levelshot.
enjoy!

=============================================================================================

Information:

Test Machine: intel c2d e6750, ocz 2gb ddr2 800mhz platinum 2, msi 8800gt 512mb oc edition

In game Support: yes
SP BOT support: yes
Tourney: yes
Deathmatch: yes
Team Deathmatch: yes
New Textures: yes
New Music: yes

=============================================================================================

Construction:

Editor Used: gtkradiant 1.5, q3build, photoshop cs3, goldwave
Known Bugs: nothing
Total Compile Time: quarter hour (x6)

=============================================================================================

Copyright:

no copyright..

=============================================================================================